/**
 * @author Rene-Angel Jaime
 * @version (10.8.19)
 */
// findKeyword("She's my sister", "sister", 0);
// iteration - 1, psn - 1, before - " ", after - nothing

// findKeyword("Brother Tom is helpful", "brother", 0);
// iteration - 1, psn - 0, before - nothing, after - " "

// findKeyword("I can't catch wild cats.", "cat", 0);
// iteration - 1, psn - 8, before - " ", after - c
// iteration - 2, psn - 19, before - " ", after - s

// findKeyword("I know nothing about snow plows.", "no", 0);
// iteration - 1, psn - 4, before - k, after - w
// iteration - 2, psn - 8, before - " ", after - h
// iteration - 3, psn - 23, before - s, after - w
